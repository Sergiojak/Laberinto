using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CambioColorPared : MonoBehaviour
{
    public float tiempoCambio = 2f; // Duraci�n del cambio de color en segundos.

    private bool cambiandoColor = false;
    private Material originalMaterial;
    private Color colorRojo = Color.red;

    private void OnCollisionEnter(Collision collision)
    {
        if (!cambiandoColor && collision.gameObject.CompareTag("Muro"))
        {
            StartCoroutine(CambiarColorPared(collision.gameObject));
        }
    }

    IEnumerator CambiarColorPared(GameObject pared)
    {
        cambiandoColor = true;

        Renderer renderer = pared.GetComponent<Renderer>();
        originalMaterial = renderer.material;

        renderer.material.color = colorRojo;

        yield return new WaitForSeconds(tiempoCambio);

        renderer.material.color = originalMaterial.color;
        cambiandoColor = false;
    }
}
