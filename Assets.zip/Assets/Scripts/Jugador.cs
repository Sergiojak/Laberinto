using System.Collections;
using UnityEngine;

public class Jugador : MonoBehaviour
{
    //movimiento en vertical y horizontal
    private float movimientoEjeX;
    private float movimientoEjeY;
    //Velocidad del personaje
    public float velocidadMovimiento = 5.0f;
    //Para el aturdimiento
    private bool aturdido = false;
    // Cuanto dura el aturdimiento 
    private float tiempoAturdimiento = 2.0f; 

    void Update()
    {
        if (!aturdido)
        {
            movimientoEjeY = Input.GetAxis("Vertical") * Time.deltaTime * velocidadMovimiento;
            movimientoEjeX = Input.GetAxis("Horizontal") * Time.deltaTime * velocidadMovimiento;
            transform.Translate(movimientoEjeX, movimientoEjeY, 0);
        }
    }

    public void Stun()
    {
        if (!aturdido)
        {
            aturdido = true;
            StartCoroutine(DesactivarAturdimiento());
        }
    }

    IEnumerator DesactivarAturdimiento()
    {
        yield return new WaitForSeconds(tiempoAturdimiento);
        aturdido = false;
    }
}

