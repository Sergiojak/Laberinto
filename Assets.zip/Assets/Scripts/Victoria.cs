using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Victoria : MonoBehaviour
{
    [SerializeField]
    GameObject Win;
    [SerializeField]
    TextMeshProUGUI TextoTiempo;

    float tiempo = 0.0f;
    bool estaJugando = true;

    private void Update()
    {
        if(estaJugando == true)
        {
            tiempo = tiempo + Time.deltaTime;
        }
    }
    private void OnTriggerEnter(Collider Victoria)
    {
        if(Victoria.tag == "Player")
        {
            Debug.Log("GANASTE");
            Win.SetActive(true);
            Victoria.GetComponent<Jugador>().enabled = false;
            estaJugando = false;
            Debug.Log(tiempo);
        }

    }



}
